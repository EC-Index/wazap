/**
 * Wazap Widget - WhatsApp Chat & Share for WooCommerce
 * Version: 1.0.0
 */
(function() {
    'use strict';

    // Check if settings exist
    if (typeof wazapSettings === 'undefined') {
        console.warn('[Wazap] Settings not found');
        return;
    }

    const settings = wazapSettings;
    
    // Exit if not enabled or no phone number
    if (settings.enabled !== '1' || !settings.phone) {
        return;
    }

    // Helper: Create element
    function createElement(tag, className, innerHTML) {
        const el = document.createElement(tag);
        if (className) el.className = className;
        if (innerHTML) el.innerHTML = innerHTML;
        return el;
    }

    // Helper: WhatsApp Icon SVG
    const whatsappIcon = `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>`;

    // Helper: Share Icon SVG
    const shareIcon = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>`;

    // Check if currently online based on business hours
    function isOnline() {
        if (settings.hoursEnabled !== '1') return true;

        const now = new Date();
        const options = { timeZone: settings.hoursTimezone || 'Europe/Berlin' };
        const localTime = new Date(now.toLocaleString('en-US', options));
        
        const day = localTime.getDay(); // 0 = Sunday
        const hours = localTime.getHours();
        const minutes = localTime.getMinutes();
        const currentMinutes = hours * 60 + minutes;

        // Weekend check
        const isWeekend = day === 0 || day === 6;
        
        if (isWeekend) {
            if (settings.hoursWeekendEnabled !== '1') return false;
            
            const [startH, startM] = settings.hoursWeekendStart.split(':').map(Number);
            const [endH, endM] = settings.hoursWeekendEnd.split(':').map(Number);
            const startMinutes = startH * 60 + startM;
            const endMinutes = endH * 60 + endM;
            
            return currentMinutes >= startMinutes && currentMinutes < endMinutes;
        } else {
            const [startH, startM] = settings.hoursWeekdayStart.split(':').map(Number);
            const [endH, endM] = settings.hoursWeekdayEnd.split(':').map(Number);
            const startMinutes = startH * 60 + startM;
            const endMinutes = endH * 60 + endM;
            
            return currentMinutes >= startMinutes && currentMinutes < endMinutes;
        }
    }

    // Build WhatsApp URL
    function buildWhatsAppURL(phone, message) {
        let text = message || settings.message || '';
        
        // Replace placeholders
        if (settings.product) {
            text = text.replace('{product}', settings.product.name);
            text = text.replace('{url}', settings.product.url);
        }
        text = text.replace('{store}', settings.store.name);
        text = text.replace('{url}', window.location.href);
        
        const encoded = encodeURIComponent(text);
        return `https://wa.me/${phone}?text=${encoded}`;
    }

    // Track event
    function trackEvent(eventType, eventData) {
        // Track in WordPress
        if (settings.ajaxUrl && settings.nonce) {
            fetch(settings.ajaxUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'wazap_track_event',
                    nonce: settings.nonce,
                    event_type: eventType,
                    ...eventData
                })
            }).catch(() => {});
        }

        // Google Analytics
        if (settings.gaEnabled === '1' && typeof gtag !== 'undefined') {
            gtag('event', eventType, {
                event_category: 'Wazap',
                event_label: eventData.label || '',
                value: eventData.value || 0
            });
        }

        // Facebook Pixel
        if (settings.fbPixelEnabled === '1' && typeof fbq !== 'undefined') {
            fbq('trackCustom', 'Wazap_' + eventType, eventData);
        }

        console.log('[Wazap]', eventType, eventData);
    }

    // Handle chat click
    function handleChatClick(phone) {
        const url = buildWhatsAppURL(phone || settings.phone, settings.message);
        trackEvent('chat_click', { phone: phone || settings.phone, online: isOnline() });
        window.open(url, '_blank');
    }

    // Handle share click
    function handleShareClick() {
        if (!settings.product) {
            console.warn('[Wazap] No product info available');
            return;
        }

        const shareText = `Hey! What do you think about this? ${settings.product.name} - ${settings.product.url}`;
        
        // Use Web Share API if available (mobile)
        if (navigator.share && /Mobi|Android/i.test(navigator.userAgent)) {
            navigator.share({
                title: settings.product.name,
                text: `What do you think about this? ${settings.product.name}`,
                url: settings.product.url
            }).then(() => {
                trackEvent('share_click', { method: 'native', product: settings.product.name });
            }).catch(() => {});
        } else {
            // Fallback to WhatsApp
            const url = `https://wa.me/?text=${encodeURIComponent(shareText)}`;
            trackEvent('share_click', { method: 'whatsapp', product: settings.product.name });
            window.open(url, '_blank');
        }
    }

    // Render widget
    function renderWidget() {
        const container = document.getElementById('wazap-widget-container');
        if (!container) return;

        // Set position class
        container.className = `wazap-${settings.position} wazap-theme-${settings.theme}`;

        // Create buttons container
        const buttonsDiv = createElement('div', 'wazap-buttons');

        // Share button (on product pages)
        if (settings.shareEnabled === '1' && settings.product) {
            const shareBtn = createElement('button', 'wazap-btn wazap-btn-share');
            shareBtn.innerHTML = `${shareIcon}<span>${settings.shareText}</span>`;
            shareBtn.addEventListener('click', handleShareClick);
            buttonsDiv.appendChild(shareBtn);
        }

        // Chat button
        if (settings.chatEnabled === '1') {
            const chatBtn = createElement('button', 'wazap-btn wazap-btn-chat');
            const online = isOnline();
            
            chatBtn.innerHTML = `
                ${whatsappIcon}
                <span>${settings.chatText}</span>
                ${settings.hoursEnabled === '1' ? `<span class="wazap-status ${online ? 'wazap-online' : 'wazap-offline'}"></span>` : ''}
            `;

            // If multiple agents enabled
            if (settings.agentsEnabled === '1' && settings.agents && settings.agents.length > 0) {
                chatBtn.addEventListener('click', () => toggleAgentPopup());
                
                // Create agent popup
                const agentPopup = createElement('div', 'wazap-agent-popup');
                agentPopup.id = 'wazap-agent-popup';
                agentPopup.innerHTML = `
                    <div class="wazap-agent-popup-header">Choose who to chat with</div>
                    <div class="wazap-agent-list">
                        ${settings.agents.filter(a => a.name && a.phone).map(agent => `
                            <a href="#" class="wazap-agent-item" data-phone="${agent.phone}">
                                <div class="wazap-agent-avatar">${agent.name.charAt(0).toUpperCase()}</div>
                                <div class="wazap-agent-info">
                                    <div class="wazap-agent-name">${agent.name}</div>
                                    <div class="wazap-agent-role">${agent.role}</div>
                                </div>
                                <div class="wazap-agent-status"></div>
                            </a>
                        `).join('')}
                    </div>
                `;
                
                container.appendChild(agentPopup);

                // Handle agent clicks
                agentPopup.querySelectorAll('.wazap-agent-item').forEach(item => {
                    item.addEventListener('click', (e) => {
                        e.preventDefault();
                        const phone = item.dataset.phone;
                        trackEvent('agent_selected', { agent: item.querySelector('.wazap-agent-name').textContent });
                        handleChatClick(phone);
                        toggleAgentPopup(false);
                    });
                });
            } else {
                chatBtn.addEventListener('click', () => handleChatClick());
            }

            buttonsDiv.appendChild(chatBtn);

            // Add offline banner if needed
            if (settings.hoursEnabled === '1' && !online) {
                const offlineBanner = createElement('div', 'wazap-offline-banner');
                offlineBanner.textContent = settings.offlineMessage || "We're currently offline";
                container.appendChild(offlineBanner);
            }
        }

        container.appendChild(buttonsDiv);

        // Cart recovery check
        if (settings.cartRecoveryEnabled === '1') {
            checkCartRecovery();
        }
    }

    // Toggle agent popup
    function toggleAgentPopup(show) {
        const popup = document.getElementById('wazap-agent-popup');
        if (!popup) return;

        if (typeof show === 'undefined') {
            popup.classList.toggle('wazap-active');
        } else {
            popup.classList.toggle('wazap-active', show);
        }
    }

    // Cart Recovery
    function checkCartRecovery() {
        const cartKey = 'wazap_cart_abandoned';
        const shownKey = 'wazap_cart_recovery_shown';
        const cartData = localStorage.getItem(cartKey);
        const alreadyShown = sessionStorage.getItem(shownKey);

        if (cartData && !alreadyShown) {
            const data = JSON.parse(cartData);
            const now = Date.now();
            const delay = parseInt(settings.cartRecoveryDelay) * 60 * 1000; // Convert minutes to ms
            const maxAge = 48 * 60 * 60 * 1000; // 48 hours

            if (now - data.timestamp > delay && now - data.timestamp < maxAge) {
                showCartRecovery();
                sessionStorage.setItem(shownKey, '1');
            }
        }

        // Save cart state on page unload (for WooCommerce cart page)
        if (document.querySelector('.woocommerce-cart') || document.querySelector('.woocommerce-checkout')) {
            window.addEventListener('beforeunload', () => {
                const hasItems = document.querySelector('.cart_item') !== null;
                if (hasItems) {
                    localStorage.setItem(cartKey, JSON.stringify({
                        timestamp: Date.now(),
                        url: window.location.href
                    }));
                }
            });
        }

        // Clear on successful order
        if (document.querySelector('.woocommerce-order-received')) {
            localStorage.removeItem(cartKey);
        }
    }

    // Show cart recovery popup
    function showCartRecovery() {
        const container = document.getElementById('wazap-widget-container');
        if (!container) return;

        const popup = createElement('div', 'wazap-cart-recovery');
        popup.innerHTML = `
            <button class="wazap-cart-recovery-close">×</button>
            <div class="wazap-cart-recovery-icon">🛒</div>
            <div class="wazap-cart-recovery-title">Forgot something?</div>
            <div class="wazap-cart-recovery-message">${settings.cartRecoveryMessage}</div>
            <button class="wazap-cart-recovery-btn">
                ${whatsappIcon}
                <span>Chat Now</span>
            </button>
        `;

        container.appendChild(popup);

        // Show with animation
        setTimeout(() => popup.classList.add('wazap-active'), 100);

        // Close button
        popup.querySelector('.wazap-cart-recovery-close').addEventListener('click', () => {
            popup.classList.remove('wazap-active');
            setTimeout(() => popup.remove(), 300);
        });

        // Chat button
        popup.querySelector('.wazap-cart-recovery-btn').addEventListener('click', () => {
            trackEvent('cart_recovery_click', {});
            handleChatClick();
            popup.classList.remove('wazap-active');
        });

        trackEvent('cart_recovery_shown', {});
    }

    // Close popup when clicking outside
    document.addEventListener('click', (e) => {
        const popup = document.getElementById('wazap-agent-popup');
        const container = document.getElementById('wazap-widget-container');
        
        if (popup && popup.classList.contains('wazap-active')) {
            if (!container.contains(e.target)) {
                toggleAgentPopup(false);
            }
        }
    });

    // Initialize
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', renderWidget);
    } else {
        renderWidget();
    }

    // Log initialization
    console.log('[Wazap] Initialized', {
        phone: settings.phone,
        position: settings.position,
        theme: settings.theme,
        chatEnabled: settings.chatEnabled,
        shareEnabled: settings.shareEnabled,
        product: settings.product ? settings.product.name : null,
        online: isOnline()
    });

})();
