/**
 * Wazap Admin Scripts
 */
jQuery(document).ready(function($) {
    
    // Toggle agents list
    $('#wazap_agents_toggle').on('change', function() {
        $('#wazap-agents-list').slideToggle(200);
    });
    
    // Toggle hours settings
    $('#wazap_hours_toggle').on('change', function() {
        $('#wazap-hours-settings').slideToggle(200);
    });
    
    // Toggle weekend hours
    $('#wazap_weekend_toggle').on('change', function() {
        $('#wazap-weekend-hours').slideToggle(200);
    });
    
    // Phone number formatting
    $('#wazap_phone').on('input', function() {
        var value = $(this).val().replace(/[^0-9]/g, '');
        $(this).val(value);
    });
    
    // Form validation
    $('form.wazap-form').on('submit', function(e) {
        var phone = $('#wazap_phone').val();
        var enabled = $('input[name="wazap_enabled"]').is(':checked');
        
        if (enabled && !phone) {
            e.preventDefault();
            alert('Please enter your WhatsApp number to enable the widget.');
            $('#wazap_phone').focus();
            return false;
        }
        
        return true;
    });
    
    // Add agent row
    $('.wazap-add-agent').on('click', function(e) {
        e.preventDefault();
        var list = $('#wazap-agents-list');
        var count = list.find('.wazap-agent-row').length;
        
        if (count >= 5) {
            alert('Maximum 5 agents allowed');
            return;
        }
        
        var newRow = `
            <div class="wazap-agent-row">
                <input type="text" name="wazap_agents[${count}][name]" placeholder="Name" class="wazap-input wazap-input-sm">
                <input type="tel" name="wazap_agents[${count}][phone]" placeholder="Phone" class="wazap-input wazap-input-sm">
                <select name="wazap_agents[${count}][role]" class="wazap-select wazap-select-sm">
                    <option value="Sales">Sales</option>
                    <option value="Support">Support</option>
                    <option value="Manager">Manager</option>
                </select>
                <button type="button" class="wazap-remove-agent" title="Remove">&times;</button>
            </div>
        `;
        
        list.append(newRow);
    });
    
    // Remove agent row
    $(document).on('click', '.wazap-remove-agent', function() {
        $(this).closest('.wazap-agent-row').remove();
    });
    
    // Preview widget position
    $('select[name="wazap_position"]').on('change', function() {
        var position = $(this).val();
        console.log('[Wazap] Position changed to:', position);
    });
    
    // Save confirmation
    $(document).on('submit', 'form.wazap-form', function() {
        var btn = $(this).find('.wazap-submit-btn');
        btn.text('Saving...').prop('disabled', true);
    });
    
});
