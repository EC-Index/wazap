<?php
/**
 * Plugin Name: Wazap - Chat & Share Buttons for WooCommerce
 * Plugin URI: https://get-wazap.com/woocommerce
 * Description: Add chat button, product sharing, multiple agents, business hours, and cart recovery to your WooCommerce store. Free forever.
 * Version: 1.0.0
 * Author: Wazap
 * Author URI: https://get-wazap.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wazap-chat-share-buttons-for-woocommerce
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 9.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WAZAP_VERSION', '1.0.0');
define('WAZAP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WAZAP_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Sanitization callbacks
 */
function wazap_sanitize_checkbox($input) {
    return ($input === '1') ? '1' : '0';
}

function wazap_sanitize_phone($input) {
    return preg_replace('/[^0-9]/', '', $input);
}

function wazap_sanitize_text($input) {
    return sanitize_text_field($input);
}

function wazap_sanitize_position($input) {
    $valid = array('bottom-right', 'bottom-left', 'bottom-center');
    return in_array($input, $valid, true) ? $input : 'bottom-right';
}

function wazap_sanitize_theme($input) {
    $valid = array('whatsapp', 'light', 'dark');
    return in_array($input, $valid, true) ? $input : 'whatsapp';
}

function wazap_sanitize_agents($input) {
    if (!is_array($input)) {
        return array();
    }
    $sanitized = array();
    foreach ($input as $agent) {
        $sanitized[] = array(
            'name' => sanitize_text_field($agent['name'] ?? ''),
            'phone' => preg_replace('/[^0-9]/', '', $agent['phone'] ?? ''),
            'role' => sanitize_text_field($agent['role'] ?? 'Sales'),
        );
    }
    return $sanitized;
}

function wazap_sanitize_time($input) {
    if (preg_match('/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/', $input)) {
        return $input;
    }
    return '09:00';
}

function wazap_sanitize_timezone($input) {
    $valid_timezones = timezone_identifiers_list();
    return in_array($input, $valid_timezones, true) ? $input : 'Europe/Berlin';
}

function wazap_sanitize_delay($input) {
    $valid = array('30', '60', '120', '1440');
    return in_array($input, $valid, true) ? $input : '60';
}

/**
 * Main Wazap Class
 */
class Wazap {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('plugins_loaded', array($this, 'init'));
    }
    
    public function init() {
        // Admin
        if (is_admin()) {
            add_action('admin_menu', array($this, 'add_admin_menu'));
            add_action('admin_init', array($this, 'register_settings'));
            add_action('admin_enqueue_scripts', array($this, 'admin_scripts'));
        }
        
        // Frontend
        add_action('wp_footer', array($this, 'render_widget'));
        add_action('wp_enqueue_scripts', array($this, 'frontend_scripts'));
        
        // AJAX
        add_action('wp_ajax_wazap_track_event', array($this, 'track_event'));
        add_action('wp_ajax_nopriv_wazap_track_event', array($this, 'track_event'));
        
        // WooCommerce hooks
        if (class_exists('WooCommerce')) {
            add_action('woocommerce_thankyou', array($this, 'clear_cart_recovery'));
        }
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            esc_html__('Wazap', 'wazap-chat-share-buttons-for-woocommerce'),
            esc_html__('Wazap', 'wazap-chat-share-buttons-for-woocommerce'),
            'manage_options',
            'wazap',
            array($this, 'admin_page'),
            'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#25D366"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>'),
            56
        );
    }
    
    /**
     * Register settings with sanitization
     */
    public function register_settings() {
        // General
        register_setting('wazap_settings', 'wazap_enabled', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_checkbox',
            'default' => '1',
        ));
        register_setting('wazap_settings', 'wazap_phone', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_phone',
            'default' => '',
        ));
        register_setting('wazap_settings', 'wazap_message', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_text',
            'default' => 'Hi! I have a question about {product}',
        ));
        register_setting('wazap_settings', 'wazap_position', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_position',
            'default' => 'bottom-right',
        ));
        register_setting('wazap_settings', 'wazap_theme', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_theme',
            'default' => 'whatsapp',
        ));
        
        // Buttons
        register_setting('wazap_settings', 'wazap_chat_enabled', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_checkbox',
            'default' => '1',
        ));
        register_setting('wazap_settings', 'wazap_chat_text', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_text',
            'default' => 'Chat',
        ));
        register_setting('wazap_settings', 'wazap_share_enabled', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_checkbox',
            'default' => '1',
        ));
        register_setting('wazap_settings', 'wazap_share_text', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_text',
            'default' => 'Get opinion',
        ));
        
        // Multiple Agents
        register_setting('wazap_settings', 'wazap_agents_enabled', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_checkbox',
            'default' => '0',
        ));
        register_setting('wazap_settings', 'wazap_agents', array(
            'type' => 'array',
            'sanitize_callback' => 'wazap_sanitize_agents',
            'default' => array(),
        ));
        
        // Business Hours
        register_setting('wazap_settings', 'wazap_hours_enabled', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_checkbox',
            'default' => '0',
        ));
        register_setting('wazap_settings', 'wazap_hours_timezone', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_timezone',
            'default' => 'Europe/Berlin',
        ));
        register_setting('wazap_settings', 'wazap_hours_weekday_start', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_time',
            'default' => '09:00',
        ));
        register_setting('wazap_settings', 'wazap_hours_weekday_end', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_time',
            'default' => '18:00',
        ));
        register_setting('wazap_settings', 'wazap_hours_weekend_enabled', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_checkbox',
            'default' => '0',
        ));
        register_setting('wazap_settings', 'wazap_hours_weekend_start', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_time',
            'default' => '10:00',
        ));
        register_setting('wazap_settings', 'wazap_hours_weekend_end', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_time',
            'default' => '14:00',
        ));
        register_setting('wazap_settings', 'wazap_offline_message', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_text',
            'default' => 'We are currently offline. Leave a message!',
        ));
        
        // Cart Recovery
        register_setting('wazap_settings', 'wazap_cart_recovery_enabled', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_checkbox',
            'default' => '1',
        ));
        register_setting('wazap_settings', 'wazap_cart_recovery_delay', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_delay',
            'default' => '60',
        ));
        register_setting('wazap_settings', 'wazap_cart_recovery_message', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_text',
            'default' => 'Still thinking about it? We can help!',
        ));
        
        // Analytics
        register_setting('wazap_settings', 'wazap_ga_enabled', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_checkbox',
            'default' => '0',
        ));
        register_setting('wazap_settings', 'wazap_fb_pixel_enabled', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_checkbox',
            'default' => '0',
        ));
        
        // Display Rules
        register_setting('wazap_settings', 'wazap_show_on_mobile', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_checkbox',
            'default' => '1',
        ));
        register_setting('wazap_settings', 'wazap_show_on_desktop', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_checkbox',
            'default' => '1',
        ));
        register_setting('wazap_settings', 'wazap_hide_on_pages', array(
            'type' => 'string',
            'sanitize_callback' => 'wazap_sanitize_text',
            'default' => '',
        ));
    }
    
    /**
     * Admin scripts
     */
    public function admin_scripts($hook) {
        if ('toplevel_page_wazap' !== $hook) {
            return;
        }
        
        wp_enqueue_style('wazap-admin', WAZAP_PLUGIN_URL . 'assets/css/admin.css', array(), WAZAP_VERSION);
        wp_enqueue_script('wazap-admin', WAZAP_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), WAZAP_VERSION, true);
    }
    
    /**
     * Frontend scripts
     */
    public function frontend_scripts() {
        if (!$this->should_show_widget()) {
            return;
        }
        
        wp_enqueue_style('wazap-widget', WAZAP_PLUGIN_URL . 'assets/css/widget.css', array(), WAZAP_VERSION);
        wp_enqueue_script('wazap-widget', WAZAP_PLUGIN_URL . 'assets/js/widget.js', array(), WAZAP_VERSION, true);
        
        // Pass settings to JS
        wp_localize_script('wazap-widget', 'wazapSettings', $this->get_widget_settings());
    }
    
    /**
     * Get widget settings for frontend
     */
    private function get_widget_settings() {
        $settings = array(
            'enabled' => get_option('wazap_enabled', '1'),
            'phone' => get_option('wazap_phone', ''),
            'message' => get_option('wazap_message', 'Hi! I have a question about {product}'),
            'position' => get_option('wazap_position', 'bottom-right'),
            'theme' => get_option('wazap_theme', 'whatsapp'),
            
            'chatEnabled' => get_option('wazap_chat_enabled', '1'),
            'chatText' => get_option('wazap_chat_text', 'Chat'),
            'shareEnabled' => get_option('wazap_share_enabled', '1'),
            'shareText' => get_option('wazap_share_text', 'Get opinion'),
            
            'agentsEnabled' => get_option('wazap_agents_enabled', '0'),
            'agents' => get_option('wazap_agents', array()),
            
            'hoursEnabled' => get_option('wazap_hours_enabled', '0'),
            'hoursTimezone' => get_option('wazap_hours_timezone', 'Europe/Berlin'),
            'hoursWeekdayStart' => get_option('wazap_hours_weekday_start', '09:00'),
            'hoursWeekdayEnd' => get_option('wazap_hours_weekday_end', '18:00'),
            'hoursWeekendEnabled' => get_option('wazap_hours_weekend_enabled', '0'),
            'hoursWeekendStart' => get_option('wazap_hours_weekend_start', '10:00'),
            'hoursWeekendEnd' => get_option('wazap_hours_weekend_end', '14:00'),
            'offlineMessage' => get_option('wazap_offline_message', 'We are currently offline. Leave a message!'),
            
            'cartRecoveryEnabled' => get_option('wazap_cart_recovery_enabled', '1'),
            'cartRecoveryDelay' => get_option('wazap_cart_recovery_delay', '60'),
            'cartRecoveryMessage' => get_option('wazap_cart_recovery_message', 'Still thinking about it? We can help!'),
            
            'gaEnabled' => get_option('wazap_ga_enabled', '0'),
            'fbPixelEnabled' => get_option('wazap_fb_pixel_enabled', '0'),
            
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wazap_nonce'),
        );
        
        // Add product info if on product page
        if (function_exists('is_product') && is_product()) {
            global $product;
            if ($product) {
                $settings['product'] = array(
                    'id' => $product->get_id(),
                    'name' => $product->get_name(),
                    'url' => get_permalink($product->get_id()),
                    'price' => $product->get_price(),
                    'image' => wp_get_attachment_url($product->get_image_id()),
                );
            }
        }
        
        // Add store info
        $settings['store'] = array(
            'name' => get_bloginfo('name'),
            'url' => home_url(),
        );
        
        return $settings;
    }
    
    /**
     * Check if widget should be shown
     */
    private function should_show_widget() {
        if (get_option('wazap_enabled', '1') !== '1') {
            return false;
        }
        
        if (empty(get_option('wazap_phone', ''))) {
            return false;
        }
        
        // Mobile/Desktop check
        $is_mobile = wp_is_mobile();
        if ($is_mobile && get_option('wazap_show_on_mobile', '1') !== '1') {
            return false;
        }
        if (!$is_mobile && get_option('wazap_show_on_desktop', '1') !== '1') {
            return false;
        }
        
        // Page exclusions
        $hide_on_pages = get_option('wazap_hide_on_pages', '');
        if (!empty($hide_on_pages)) {
            $hidden_pages = array_map('trim', explode(',', $hide_on_pages));
            if (is_page($hidden_pages)) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Render widget container (JS handles the rest)
     */
    public function render_widget() {
        if (!$this->should_show_widget()) {
            return;
        }
        
        echo '<div id="wazap-widget-container"></div>';
    }
    
    /**
     * Track event via AJAX
     */
    public function track_event() {
        check_ajax_referer('wazap_nonce', 'nonce');
        
        $event_type = isset($_POST['event_type']) ? sanitize_text_field(wp_unslash($_POST['event_type'])) : '';
        $event_data = array();
        
        if (isset($_POST['event_data']) && is_array($_POST['event_data'])) {
            foreach ($_POST['event_data'] as $key => $value) {
                $event_data[sanitize_key($key)] = sanitize_text_field(wp_unslash($value));
            }
        }
        
        // Store in options or custom table
        $events = get_option('wazap_analytics', array());
        $events[] = array(
            'type' => $event_type,
            'data' => $event_data,
            'timestamp' => current_time('mysql'),
        );
        
        // Keep only last 1000 events
        if (count($events) > 1000) {
            $events = array_slice($events, -1000);
        }
        
        update_option('wazap_analytics', $events);
        
        wp_send_json_success();
    }
    
    /**
     * Clear cart recovery after successful order
     */
    public function clear_cart_recovery($order_id) {
        // This will be handled by JS clearing localStorage
    }
    
    /**
     * Admin page
     */
    public function admin_page() {
        // Get analytics data
        $events = get_option('wazap_analytics', array());
        $today = gmdate('Y-m-d');
        
        $stats = array(
            'chats_today' => 0,
            'shares_today' => 0,
            'chats_total' => 0,
            'shares_total' => 0,
        );
        
        foreach ($events as $event) {
            if ($event['type'] === 'chat_click') {
                $stats['chats_total']++;
                if (strpos($event['timestamp'], $today) === 0) {
                    $stats['chats_today']++;
                }
            }
            if ($event['type'] === 'share_click') {
                $stats['shares_total']++;
                if (strpos($event['timestamp'], $today) === 0) {
                    $stats['shares_today']++;
                }
            }
        }
        
        include WAZAP_PLUGIN_DIR . 'templates/admin-page.php';
    }
}

// Initialize
Wazap::get_instance();

// Activation hook
register_activation_hook(__FILE__, function() {
    // Set default options
    add_option('wazap_enabled', '1');
    add_option('wazap_chat_enabled', '1');
    add_option('wazap_share_enabled', '1');
    add_option('wazap_chat_text', 'Chat');
    add_option('wazap_share_text', 'Get opinion');
    add_option('wazap_position', 'bottom-right');
    add_option('wazap_theme', 'whatsapp');
    add_option('wazap_message', 'Hi! I have a question about {product}');
    add_option('wazap_show_on_mobile', '1');
    add_option('wazap_show_on_desktop', '1');
    add_option('wazap_cart_recovery_enabled', '1');
    add_option('wazap_cart_recovery_delay', '60');
    add_option('wazap_hours_weekday_start', '09:00');
    add_option('wazap_hours_weekday_end', '18:00');
});

// Deactivation hook
register_deactivation_hook(__FILE__, function() {
    // Cleanup if needed
});
