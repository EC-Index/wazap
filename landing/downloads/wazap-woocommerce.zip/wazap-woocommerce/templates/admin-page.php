<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="wrap wazap-admin">
    <div class="wazap-header">
        <div class="wazap-logo">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="#25D366">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
            </svg>
            <h1>Wazap</h1>
            <span class="wazap-version">v<?php echo WAZAP_VERSION; ?></span>
        </div>
        <a href="https://get-wazap.com/docs" target="_blank" class="wazap-help-link">
            📖 Documentation
        </a>
    </div>

    <?php if (empty(get_option('wazap_phone'))): ?>
    <div class="wazap-notice wazap-notice-warning">
        <strong>⚠️ Setup Required:</strong> Enter your WhatsApp number below to activate the widget.
    </div>
    <?php endif; ?>

    <!-- Stats Cards -->
    <div class="wazap-stats">
        <div class="wazap-stat-card">
            <div class="wazap-stat-icon">💬</div>
            <div class="wazap-stat-content">
                <div class="wazap-stat-value"><?php echo esc_html($stats['chats_today']); ?></div>
                <div class="wazap-stat-label">Chats Today</div>
            </div>
        </div>
        <div class="wazap-stat-card">
            <div class="wazap-stat-icon">📤</div>
            <div class="wazap-stat-content">
                <div class="wazap-stat-value"><?php echo esc_html($stats['shares_today']); ?></div>
                <div class="wazap-stat-label">Shares Today</div>
            </div>
        </div>
        <div class="wazap-stat-card">
            <div class="wazap-stat-icon">📊</div>
            <div class="wazap-stat-content">
                <div class="wazap-stat-value"><?php echo esc_html($stats['chats_total']); ?></div>
                <div class="wazap-stat-label">Total Chats</div>
            </div>
        </div>
        <div class="wazap-stat-card">
            <div class="wazap-stat-icon">🚀</div>
            <div class="wazap-stat-content">
                <div class="wazap-stat-value"><?php echo esc_html($stats['shares_total']); ?></div>
                <div class="wazap-stat-label">Total Shares</div>
            </div>
        </div>
    </div>

    <form method="post" action="options.php" class="wazap-form">
        <?php settings_fields('wazap_settings'); ?>
        
        <div class="wazap-settings-grid">
            <!-- Main Settings -->
            <div class="wazap-card">
                <div class="wazap-card-header">
                    <h2>📱 General Settings</h2>
                </div>
                <div class="wazap-card-body">
                    <div class="wazap-field">
                        <label class="wazap-toggle">
                            <input type="checkbox" name="wazap_enabled" value="1" <?php checked(get_option('wazap_enabled', '1'), '1'); ?>>
                            <span class="wazap-toggle-slider"></span>
                            <span class="wazap-toggle-label">Enable Wazap Widget</span>
                        </label>
                    </div>
                    
                    <div class="wazap-field">
                        <label for="wazap_phone">WhatsApp Number *</label>
                        <input type="tel" id="wazap_phone" name="wazap_phone" value="<?php echo esc_attr(get_option('wazap_phone', '')); ?>" placeholder="491701234567" class="wazap-input">
                        <p class="wazap-field-hint">Include country code without + (e.g., 491701234567)</p>
                    </div>
                    
                    <div class="wazap-field">
                        <label for="wazap_message">Default Message</label>
                        <input type="text" id="wazap_message" name="wazap_message" value="<?php echo esc_attr(get_option('wazap_message', 'Hi! I have a question about {product}')); ?>" class="wazap-input">
                        <p class="wazap-field-hint">Use {product}, {url}, {store} as placeholders</p>
                    </div>
                    
                    <div class="wazap-field-row">
                        <div class="wazap-field">
                            <label for="wazap_position">Position</label>
                            <select id="wazap_position" name="wazap_position" class="wazap-select">
                                <option value="bottom-right" <?php selected(get_option('wazap_position', 'bottom-right'), 'bottom-right'); ?>>Bottom Right</option>
                                <option value="bottom-left" <?php selected(get_option('wazap_position'), 'bottom-left'); ?>>Bottom Left</option>
                                <option value="bottom-center" <?php selected(get_option('wazap_position'), 'bottom-center'); ?>>Bottom Center</option>
                            </select>
                        </div>
                        
                        <div class="wazap-field">
                            <label for="wazap_theme">Theme</label>
                            <select id="wazap_theme" name="wazap_theme" class="wazap-select">
                                <option value="whatsapp" <?php selected(get_option('wazap_theme', 'whatsapp'), 'whatsapp'); ?>>WhatsApp Green</option>
                                <option value="light" <?php selected(get_option('wazap_theme'), 'light'); ?>>Light</option>
                                <option value="dark" <?php selected(get_option('wazap_theme'), 'dark'); ?>>Dark</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Button Settings -->
            <div class="wazap-card">
                <div class="wazap-card-header">
                    <h2>🔘 Button Settings</h2>
                </div>
                <div class="wazap-card-body">
                    <div class="wazap-field">
                        <label class="wazap-toggle">
                            <input type="checkbox" name="wazap_chat_enabled" value="1" <?php checked(get_option('wazap_chat_enabled', '1'), '1'); ?>>
                            <span class="wazap-toggle-slider"></span>
                            <span class="wazap-toggle-label">Show Chat Button</span>
                        </label>
                    </div>
                    
                    <div class="wazap-field">
                        <label for="wazap_chat_text">Chat Button Text</label>
                        <select id="wazap_chat_text" name="wazap_chat_text" class="wazap-select">
                            <option value="Chat" <?php selected(get_option('wazap_chat_text', 'Chat'), 'Chat'); ?>>💬 Chat</option>
                            <option value="Ask us" <?php selected(get_option('wazap_chat_text'), 'Ask us'); ?>>❓ Ask us</option>
                            <option value="Help" <?php selected(get_option('wazap_chat_text'), 'Help'); ?>>🆘 Help</option>
                            <option value="Questions?" <?php selected(get_option('wazap_chat_text'), 'Questions?'); ?>>❓ Questions?</option>
                            <option value="Contact" <?php selected(get_option('wazap_chat_text'), 'Contact'); ?>>📞 Contact</option>
                        </select>
                    </div>
                    
                    <hr class="wazap-divider">
                    
                    <div class="wazap-field">
                        <label class="wazap-toggle">
                            <input type="checkbox" name="wazap_share_enabled" value="1" <?php checked(get_option('wazap_share_enabled', '1'), '1'); ?>>
                            <span class="wazap-toggle-slider"></span>
                            <span class="wazap-toggle-label">Show Share Button</span>
                        </label>
                        <p class="wazap-field-hint">Let customers share products with friends via WhatsApp</p>
                    </div>
                    
                    <div class="wazap-field">
                        <label for="wazap_share_text">Share Button Text</label>
                        <select id="wazap_share_text" name="wazap_share_text" class="wazap-select">
                            <option value="Get opinion" <?php selected(get_option('wazap_share_text', 'Get opinion'), 'Get opinion'); ?>>💬 Get opinion (recommended)</option>
                            <option value="Ask a friend" <?php selected(get_option('wazap_share_text'), 'Ask a friend'); ?>>👋 Ask a friend</option>
                            <option value="Share" <?php selected(get_option('wazap_share_text'), 'Share'); ?>>📤 Share</option>
                            <option value="Send to friend" <?php selected(get_option('wazap_share_text'), 'Send to friend'); ?>>📤 Send to friend</option>
                        </select>
                        <p class="wazap-field-hint">"Get opinion" converts 2× better than "Share"</p>
                    </div>
                </div>
            </div>

            <!-- Multiple Agents -->
            <div class="wazap-card">
                <div class="wazap-card-header">
                    <h2>👥 Multiple Agents</h2>
                    <span class="wazap-badge wazap-badge-free">FREE</span>
                </div>
                <div class="wazap-card-body">
                    <div class="wazap-field">
                        <label class="wazap-toggle">
                            <input type="checkbox" name="wazap_agents_enabled" value="1" <?php checked(get_option('wazap_agents_enabled', '0'), '1'); ?> id="wazap_agents_toggle">
                            <span class="wazap-toggle-slider"></span>
                            <span class="wazap-toggle-label">Enable Multiple Agents</span>
                        </label>
                        <p class="wazap-field-hint">Let customers choose who to chat with</p>
                    </div>
                    
                    <div id="wazap-agents-list" class="wazap-agents-list" style="<?php echo get_option('wazap_agents_enabled', '0') === '1' ? '' : 'display:none;'; ?>">
                        <?php 
                        $agents = get_option('wazap_agents', array());
                        if (empty($agents)) {
                            $agents = array(
                                array('name' => '', 'phone' => '', 'role' => 'Sales'),
                                array('name' => '', 'phone' => '', 'role' => 'Support'),
                            );
                        }
                        foreach ($agents as $i => $agent): 
                        ?>
                        <div class="wazap-agent-row">
                            <input type="text" name="wazap_agents[<?php echo $i; ?>][name]" value="<?php echo esc_attr($agent['name'] ?? ''); ?>" placeholder="Name" class="wazap-input wazap-input-sm">
                            <input type="tel" name="wazap_agents[<?php echo $i; ?>][phone]" value="<?php echo esc_attr($agent['phone'] ?? ''); ?>" placeholder="Phone" class="wazap-input wazap-input-sm">
                            <select name="wazap_agents[<?php echo $i; ?>][role]" class="wazap-select wazap-select-sm">
                                <option value="Sales" <?php selected($agent['role'] ?? '', 'Sales'); ?>>Sales</option>
                                <option value="Support" <?php selected($agent['role'] ?? '', 'Support'); ?>>Support</option>
                                <option value="Manager" <?php selected($agent['role'] ?? '', 'Manager'); ?>>Manager</option>
                            </select>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Business Hours -->
            <div class="wazap-card">
                <div class="wazap-card-header">
                    <h2>🕐 Business Hours</h2>
                    <span class="wazap-badge wazap-badge-free">FREE</span>
                </div>
                <div class="wazap-card-body">
                    <div class="wazap-field">
                        <label class="wazap-toggle">
                            <input type="checkbox" name="wazap_hours_enabled" value="1" <?php checked(get_option('wazap_hours_enabled', '0'), '1'); ?> id="wazap_hours_toggle">
                            <span class="wazap-toggle-slider"></span>
                            <span class="wazap-toggle-label">Enable Business Hours</span>
                        </label>
                        <p class="wazap-field-hint">Show online/offline status based on your hours</p>
                    </div>
                    
                    <div id="wazap-hours-settings" style="<?php echo get_option('wazap_hours_enabled', '0') === '1' ? '' : 'display:none;'; ?>">
                        <div class="wazap-field">
                            <label for="wazap_hours_timezone">Timezone</label>
                            <select id="wazap_hours_timezone" name="wazap_hours_timezone" class="wazap-select">
                                <?php
                                $timezones = array(
                                    'Europe/Berlin' => 'Berlin (CET)',
                                    'Europe/London' => 'London (GMT)',
                                    'America/New_York' => 'New York (EST)',
                                    'America/Los_Angeles' => 'Los Angeles (PST)',
                                    'Asia/Kolkata' => 'India (IST)',
                                    'Asia/Dubai' => 'Dubai (GST)',
                                    'Asia/Tokyo' => 'Tokyo (JST)',
                                    'Australia/Sydney' => 'Sydney (AEST)',
                                );
                                $current_tz = get_option('wazap_hours_timezone', 'Europe/Berlin');
                                foreach ($timezones as $tz => $label):
                                ?>
                                <option value="<?php echo esc_attr($tz); ?>" <?php selected($current_tz, $tz); ?>><?php echo esc_html($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="wazap-hours-group">
                            <label>Weekdays (Mon-Fri)</label>
                            <div class="wazap-time-range">
                                <input type="time" name="wazap_hours_weekday_start" value="<?php echo esc_attr(get_option('wazap_hours_weekday_start', '09:00')); ?>" class="wazap-input wazap-input-sm">
                                <span>to</span>
                                <input type="time" name="wazap_hours_weekday_end" value="<?php echo esc_attr(get_option('wazap_hours_weekday_end', '18:00')); ?>" class="wazap-input wazap-input-sm">
                            </div>
                        </div>
                        
                        <div class="wazap-field">
                            <label class="wazap-toggle">
                                <input type="checkbox" name="wazap_hours_weekend_enabled" value="1" <?php checked(get_option('wazap_hours_weekend_enabled', '0'), '1'); ?> id="wazap_weekend_toggle">
                                <span class="wazap-toggle-slider"></span>
                                <span class="wazap-toggle-label">Open on Weekends</span>
                            </label>
                        </div>
                        
                        <div id="wazap-weekend-hours" class="wazap-hours-group" style="<?php echo get_option('wazap_hours_weekend_enabled', '0') === '1' ? '' : 'display:none;'; ?>">
                            <label>Weekend (Sat-Sun)</label>
                            <div class="wazap-time-range">
                                <input type="time" name="wazap_hours_weekend_start" value="<?php echo esc_attr(get_option('wazap_hours_weekend_start', '10:00')); ?>" class="wazap-input wazap-input-sm">
                                <span>to</span>
                                <input type="time" name="wazap_hours_weekend_end" value="<?php echo esc_attr(get_option('wazap_hours_weekend_end', '14:00')); ?>" class="wazap-input wazap-input-sm">
                            </div>
                        </div>
                        
                        <div class="wazap-field">
                            <label for="wazap_offline_message">Offline Message</label>
                            <input type="text" id="wazap_offline_message" name="wazap_offline_message" value="<?php echo esc_attr(get_option('wazap_offline_message', 'We are currently offline. Leave a message!')); ?>" class="wazap-input">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Cart Recovery -->
            <div class="wazap-card">
                <div class="wazap-card-header">
                    <h2>🛒 Cart Recovery</h2>
                    <span class="wazap-badge wazap-badge-free">FREE</span>
                </div>
                <div class="wazap-card-body">
                    <div class="wazap-field">
                        <label class="wazap-toggle">
                            <input type="checkbox" name="wazap_cart_recovery_enabled" value="1" <?php checked(get_option('wazap_cart_recovery_enabled', '1'), '1'); ?>>
                            <span class="wazap-toggle-slider"></span>
                            <span class="wazap-toggle-label">Enable Cart Recovery</span>
                        </label>
                        <p class="wazap-field-hint">Show a popup when customers return after abandoning cart</p>
                    </div>
                    
                    <div class="wazap-field">
                        <label for="wazap_cart_recovery_delay">Show popup after (minutes)</label>
                        <select id="wazap_cart_recovery_delay" name="wazap_cart_recovery_delay" class="wazap-select">
                            <option value="30" <?php selected(get_option('wazap_cart_recovery_delay', '60'), '30'); ?>>30 minutes</option>
                            <option value="60" <?php selected(get_option('wazap_cart_recovery_delay', '60'), '60'); ?>>1 hour</option>
                            <option value="120" <?php selected(get_option('wazap_cart_recovery_delay', '60'), '120'); ?>>2 hours</option>
                            <option value="1440" <?php selected(get_option('wazap_cart_recovery_delay', '60'), '1440'); ?>>24 hours</option>
                        </select>
                    </div>
                    
                    <div class="wazap-field">
                        <label for="wazap_cart_recovery_message">Recovery Message</label>
                        <input type="text" id="wazap_cart_recovery_message" name="wazap_cart_recovery_message" value="<?php echo esc_attr(get_option('wazap_cart_recovery_message', 'Still thinking about it? We can help!')); ?>" class="wazap-input">
                    </div>
                </div>
            </div>

            <!-- Analytics -->
            <div class="wazap-card">
                <div class="wazap-card-header">
                    <h2>📊 Analytics</h2>
                </div>
                <div class="wazap-card-body">
                    <div class="wazap-field">
                        <label class="wazap-toggle">
                            <input type="checkbox" name="wazap_ga_enabled" value="1" <?php checked(get_option('wazap_ga_enabled', '0'), '1'); ?>>
                            <span class="wazap-toggle-slider"></span>
                            <span class="wazap-toggle-label">Send events to Google Analytics</span>
                        </label>
                        <p class="wazap-field-hint">Requires GA4 to be installed on your site</p>
                    </div>
                    
                    <div class="wazap-field">
                        <label class="wazap-toggle">
                            <input type="checkbox" name="wazap_fb_pixel_enabled" value="1" <?php checked(get_option('wazap_fb_pixel_enabled', '0'), '1'); ?>>
                            <span class="wazap-toggle-slider"></span>
                            <span class="wazap-toggle-label">Send events to Facebook Pixel</span>
                        </label>
                        <p class="wazap-field-hint">Requires Facebook Pixel to be installed</p>
                    </div>
                </div>
            </div>

            <!-- Display Rules -->
            <div class="wazap-card">
                <div class="wazap-card-header">
                    <h2>👁️ Display Rules</h2>
                </div>
                <div class="wazap-card-body">
                    <div class="wazap-field-row">
                        <div class="wazap-field">
                            <label class="wazap-toggle">
                                <input type="checkbox" name="wazap_show_on_mobile" value="1" <?php checked(get_option('wazap_show_on_mobile', '1'), '1'); ?>>
                                <span class="wazap-toggle-slider"></span>
                                <span class="wazap-toggle-label">Show on Mobile</span>
                            </label>
                        </div>
                        
                        <div class="wazap-field">
                            <label class="wazap-toggle">
                                <input type="checkbox" name="wazap_show_on_desktop" value="1" <?php checked(get_option('wazap_show_on_desktop', '1'), '1'); ?>>
                                <span class="wazap-toggle-slider"></span>
                                <span class="wazap-toggle-label">Show on Desktop</span>
                            </label>
                        </div>
                    </div>
                    
                    <div class="wazap-field">
                        <label for="wazap_hide_on_pages">Hide on Pages</label>
                        <input type="text" id="wazap_hide_on_pages" name="wazap_hide_on_pages" value="<?php echo esc_attr(get_option('wazap_hide_on_pages', '')); ?>" placeholder="cart, checkout, my-account" class="wazap-input">
                        <p class="wazap-field-hint">Comma-separated page slugs where widget should be hidden</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="wazap-submit-row">
            <?php submit_button(__('Save Settings', 'wazap'), 'primary wazap-submit-btn', 'submit', false); ?>
        </div>
    </form>
    
    <div class="wazap-footer">
        <p>Made with ❤️ by <a href="https://get-wazap.com" target="_blank">Wazap</a> | 
        <a href="https://get-wazap.com/docs" target="_blank">Documentation</a> | 
        <a href="https://get-wazap.com/support" target="_blank">Support</a></p>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Toggle agents list
    $('#wazap_agents_toggle').on('change', function() {
        $('#wazap-agents-list').toggle(this.checked);
    });
    
    // Toggle hours settings
    $('#wazap_hours_toggle').on('change', function() {
        $('#wazap-hours-settings').toggle(this.checked);
    });
    
    // Toggle weekend hours
    $('#wazap_weekend_toggle').on('change', function() {
        $('#wazap-weekend-hours').toggle(this.checked);
    });
});
</script>
