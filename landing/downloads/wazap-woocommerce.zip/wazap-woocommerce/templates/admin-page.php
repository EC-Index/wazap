<?php
/**
 * Admin page template
 *
 * @package Wazap
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<div class="wrap wazap-admin">
    <div class="wazap-header">
        <div class="wazap-logo">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="#25D366">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
            </svg>
            <h1><?php esc_html_e( 'Wazap', 'wazap-chat-share-buttons-for-woocommerce' ); ?></h1>
            <span class="wazap-version">v<?php echo esc_html( WAZAP_VERSION ); ?></span>
        </div>
        <a href="https://get-wazap.com/docs" target="_blank" class="wazap-help-link">
            <?php esc_html_e( 'Documentation', 'wazap-chat-share-buttons-for-woocommerce' ); ?>
        </a>
    </div>

    <?php if ( empty( get_option( 'wazap_phone' ) ) ) : ?>
    <div class="wazap-notice wazap-notice-warning">
        <strong><?php esc_html_e( 'Setup Required:', 'wazap-chat-share-buttons-for-woocommerce' ); ?></strong> 
        <?php esc_html_e( 'Enter your phone number below to activate the widget.', 'wazap-chat-share-buttons-for-woocommerce' ); ?>
    </div>
    <?php endif; ?>

    <!-- Stats Cards -->
    <div class="wazap-stats">
        <div class="wazap-stat-card">
            <div class="wazap-stat-icon">💬</div>
            <div class="wazap-stat-content">
                <div class="wazap-stat-value"><?php echo esc_html( $stats['chats_today'] ); ?></div>
                <div class="wazap-stat-label"><?php esc_html_e( 'Chats Today', 'wazap-chat-share-buttons-for-woocommerce' ); ?></div>
            </div>
        </div>
        <div class="wazap-stat-card">
            <div class="wazap-stat-icon">📤</div>
            <div class="wazap-stat-content">
                <div class="wazap-stat-value"><?php echo esc_html( $stats['shares_today'] ); ?></div>
                <div class="wazap-stat-label"><?php esc_html_e( 'Shares Today', 'wazap-chat-share-buttons-for-woocommerce' ); ?></div>
            </div>
        </div>
        <div class="wazap-stat-card">
            <div class="wazap-stat-icon">📊</div>
            <div class="wazap-stat-content">
                <div class="wazap-stat-value"><?php echo esc_html( $stats['chats_total'] ); ?></div>
                <div class="wazap-stat-label"><?php esc_html_e( 'Total Chats', 'wazap-chat-share-buttons-for-woocommerce' ); ?></div>
            </div>
        </div>
        <div class="wazap-stat-card">
            <div class="wazap-stat-icon">🚀</div>
            <div class="wazap-stat-content">
                <div class="wazap-stat-value"><?php echo esc_html( $stats['shares_total'] ); ?></div>
                <div class="wazap-stat-label"><?php esc_html_e( 'Total Shares', 'wazap-chat-share-buttons-for-woocommerce' ); ?></div>
            </div>
        </div>
    </div>

    <form method="post" action="options.php" class="wazap-form">
        <?php settings_fields( 'wazap_settings' ); ?>
        
        <div class="wazap-settings-grid">
            <!-- Main Settings -->
            <div class="wazap-card">
                <div class="wazap-card-header">
                    <h2><?php esc_html_e( 'General Settings', 'wazap-chat-share-buttons-for-woocommerce' ); ?></h2>
                </div>
                <div class="wazap-card-body">
                    <div class="wazap-field">
                        <label class="wazap-toggle">
                            <input type="checkbox" name="wazap_enabled" value="1" <?php checked( get_option( 'wazap_enabled', '1' ), '1' ); ?>>
                            <span class="wazap-toggle-slider"></span>
                            <span class="wazap-toggle-label"><?php esc_html_e( 'Enable Wazap Widget', 'wazap-chat-share-buttons-for-woocommerce' ); ?></span>
                        </label>
                    </div>
                    
                    <div class="wazap-field">
                        <label for="wazap_phone"><?php esc_html_e( 'Phone Number *', 'wazap-chat-share-buttons-for-woocommerce' ); ?></label>
                        <input type="tel" id="wazap_phone" name="wazap_phone" value="<?php echo esc_attr( get_option( 'wazap_phone', '' ) ); ?>" placeholder="491701234567" class="wazap-input">
                        <p class="wazap-field-hint"><?php esc_html_e( 'Include country code without + (e.g., 491701234567)', 'wazap-chat-share-buttons-for-woocommerce' ); ?></p>
                    </div>
                    
                    <div class="wazap-field">
                        <label for="wazap_message"><?php esc_html_e( 'Default Message', 'wazap-chat-share-buttons-for-woocommerce' ); ?></label>
                        <input type="text" id="wazap_message" name="wazap_message" value="<?php echo esc_attr( get_option( 'wazap_message', 'Hi! I have a question about {product}' ) ); ?>" class="wazap-input">
                        <p class="wazap-field-hint"><?php esc_html_e( 'Use {product}, {url}, {store} as placeholders', 'wazap-chat-share-buttons-for-woocommerce' ); ?></p>
                    </div>
                    
                    <div class="wazap-field-row">
                        <div class="wazap-field">
                            <label for="wazap_position"><?php esc_html_e( 'Position', 'wazap-chat-share-buttons-for-woocommerce' ); ?></label>
                            <select id="wazap_position" name="wazap_position" class="wazap-select">
                                <option value="bottom-right" <?php selected( get_option( 'wazap_position', 'bottom-right' ), 'bottom-right' ); ?>><?php esc_html_e( 'Bottom Right', 'wazap-chat-share-buttons-for-woocommerce' ); ?></option>
                                <option value="bottom-left" <?php selected( get_option( 'wazap_position' ), 'bottom-left' ); ?>><?php esc_html_e( 'Bottom Left', 'wazap-chat-share-buttons-for-woocommerce' ); ?></option>
                                <option value="bottom-center" <?php selected( get_option( 'wazap_position' ), 'bottom-center' ); ?>><?php esc_html_e( 'Bottom Center', 'wazap-chat-share-buttons-for-woocommerce' ); ?></option>
                            </select>
                        </div>
                        
                        <div class="wazap-field">
                            <label for="wazap_theme"><?php esc_html_e( 'Theme', 'wazap-chat-share-buttons-for-woocommerce' ); ?></label>
                            <select id="wazap_theme" name="wazap_theme" class="wazap-select">
                                <option value="whatsapp" <?php selected( get_option( 'wazap_theme', 'whatsapp' ), 'whatsapp' ); ?>><?php esc_html_e( 'Green', 'wazap-chat-share-buttons-for-woocommerce' ); ?></option>
                                <option value="light" <?php selected( get_option( 'wazap_theme' ), 'light' ); ?>><?php esc_html_e( 'Light', 'wazap-chat-share-buttons-for-woocommerce' ); ?></option>
                                <option value="dark" <?php selected( get_option( 'wazap_theme' ), 'dark' ); ?>><?php esc_html_e( 'Dark', 'wazap-chat-share-buttons-for-woocommerce' ); ?></option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Button Settings -->
            <div class="wazap-card">
                <div class="wazap-card-header">
                    <h2><?php esc_html_e( 'Button Settings', 'wazap-chat-share-buttons-for-woocommerce' ); ?></h2>
                </div>
                <div class="wazap-card-body">
                    <div class="wazap-field">
                        <label class="wazap-toggle">
                            <input type="checkbox" name="wazap_chat_enabled" value="1" <?php checked( get_option( 'wazap_chat_enabled', '1' ), '1' ); ?>>
                            <span class="wazap-toggle-slider"></span>
                            <span class="wazap-toggle-label"><?php esc_html_e( 'Show Chat Button', 'wazap-chat-share-buttons-for-woocommerce' ); ?></span>
                        </label>
                    </div>
                    
                    <div class="wazap-field">
                        <label for="wazap_chat_text"><?php esc_html_e( 'Chat Button Text', 'wazap-chat-share-buttons-for-woocommerce' ); ?></label>
                        <select id="wazap_chat_text" name="wazap_chat_text" class="wazap-select">
                            <option value="Chat" <?php selected( get_option( 'wazap_chat_text', 'Chat' ), 'Chat' ); ?>>Chat</option>
                            <option value="Ask us" <?php selected( get_option( 'wazap_chat_text' ), 'Ask us' ); ?>>Ask us</option>
                            <option value="Help" <?php selected( get_option( 'wazap_chat_text' ), 'Help' ); ?>>Help</option>
                            <option value="Questions?" <?php selected( get_option( 'wazap_chat_text' ), 'Questions?' ); ?>>Questions?</option>
                            <option value="Contact" <?php selected( get_option( 'wazap_chat_text' ), 'Contact' ); ?>>Contact</option>
                        </select>
                    </div>
                    
                    <hr class="wazap-divider">
                    
                    <div class="wazap-field">
                        <label class="wazap-toggle">
                            <input type="checkbox" name="wazap_share_enabled" value="1" <?php checked( get_option( 'wazap_share_enabled', '1' ), '1' ); ?>>
                            <span class="wazap-toggle-slider"></span>
                            <span class="wazap-toggle-label"><?php esc_html_e( 'Show Share Button', 'wazap-chat-share-buttons-for-woocommerce' ); ?></span>
                        </label>
                        <p class="wazap-field-hint"><?php esc_html_e( 'Customers can share products with friends', 'wazap-chat-share-buttons-for-woocommerce' ); ?></p>
                    </div>
                    
                    <div class="wazap-field">
                        <label for="wazap_share_text"><?php esc_html_e( 'Share Button Text', 'wazap-chat-share-buttons-for-woocommerce' ); ?></label>
                        <select id="wazap_share_text" name="wazap_share_text" class="wazap-select">
                            <option value="Get opinion" <?php selected( get_option( 'wazap_share_text', 'Get opinion' ), 'Get opinion' ); ?>>Get opinion</option>
                            <option value="Share" <?php selected( get_option( 'wazap_share_text' ), 'Share' ); ?>>Share</option>
                            <option value="Ask a friend" <?php selected( get_option( 'wazap_share_text' ), 'Ask a friend' ); ?>>Ask a friend</option>
                            <option value="Send to friend" <?php selected( get_option( 'wazap_share_text' ), 'Send to friend' ); ?>>Send to friend</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Multiple Agents -->
            <div class="wazap-card">
                <div class="wazap-card-header">
                    <h2><?php esc_html_e( 'Multiple Agents', 'wazap-chat-share-buttons-for-woocommerce' ); ?></h2>
                    <span class="wazap-badge wazap-badge-free"><?php esc_html_e( 'FREE', 'wazap-chat-share-buttons-for-woocommerce' ); ?></span>
                </div>
                <div class="wazap-card-body">
                    <div class="wazap-field">
                        <label class="wazap-toggle">
                            <input type="checkbox" name="wazap_agents_enabled" value="1" id="wazap_agents_toggle" <?php checked( get_option( 'wazap_agents_enabled', '0' ), '1' ); ?>>
                            <span class="wazap-toggle-slider"></span>
                            <span class="wazap-toggle-label"><?php esc_html_e( 'Enable Multiple Agents', 'wazap-chat-share-buttons-for-woocommerce' ); ?></span>
                        </label>
                        <p class="wazap-field-hint"><?php esc_html_e( 'Let customers choose who to chat with', 'wazap-chat-share-buttons-for-woocommerce' ); ?></p>
                    </div>
                    
                    <div id="wazap-agents-list" style="<?php echo ( get_option( 'wazap_agents_enabled', '0' ) === '1' ) ? '' : 'display:none;'; ?>">
                        <?php
                        $agents = get_option( 'wazap_agents', array() );
                        for ( $i = 0; $i < 5; $i++ ) :
                            $agent = isset( $agents[ $i ] ) ? $agents[ $i ] : array(
                                'name'  => '',
                                'phone' => '',
                                'role'  => 'Sales',
                            );
                        ?>
                        <div class="wazap-agent-row">
                            <input type="text" name="wazap_agents[<?php echo esc_attr( $i ); ?>][name]" value="<?php echo esc_attr( $agent['name'] ); ?>" placeholder="<?php esc_attr_e( 'Name', 'wazap-chat-share-buttons-for-woocommerce' ); ?>" class="wazap-input wazap-input-sm">
                            <input type="tel" name="wazap_agents[<?php echo esc_attr( $i ); ?>][phone]" value="<?php echo esc_attr( $agent['phone'] ); ?>" placeholder="<?php esc_attr_e( 'Phone', 'wazap-chat-share-buttons-for-woocommerce' ); ?>" class="wazap-input wazap-input-sm">
                            <select name="wazap_agents[<?php echo esc_attr( $i ); ?>][role]" class="wazap-select wazap-select-sm">
                                <option value="Sales" <?php selected( $agent['role'], 'Sales' ); ?>><?php esc_html_e( 'Sales', 'wazap-chat-share-buttons-for-woocommerce' ); ?></option>
                                <option value="Support" <?php selected( $agent['role'], 'Support' ); ?>><?php esc_html_e( 'Support', 'wazap-chat-share-buttons-for-woocommerce' ); ?></option>
                                <option value="Manager" <?php selected( $agent['role'], 'Manager' ); ?>><?php esc_html_e( 'Manager', 'wazap-chat-share-buttons-for-woocommerce' ); ?></option>
                            </select>
                        </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>

            <!-- Business Hours -->
            <div class="wazap-card">
                <div class="wazap-card-header">
                    <h2><?php esc_html_e( 'Business Hours', 'wazap-chat-share-buttons-for-woocommerce' ); ?></h2>
                    <span class="wazap-badge wazap-badge-free"><?php esc_html_e( 'FREE', 'wazap-chat-share-buttons-for-woocommerce' ); ?></span>
                </div>
                <div class="wazap-card-body">
                    <div class="wazap-field">
                        <label class="wazap-toggle">
                            <input type="checkbox" name="wazap_hours_enabled" value="1" id="wazap_hours_toggle" <?php checked( get_option( 'wazap_hours_enabled', '0' ), '1' ); ?>>
                            <span class="wazap-toggle-slider"></span>
                            <span class="wazap-toggle-label"><?php esc_html_e( 'Enable Business Hours', 'wazap-chat-share-buttons-for-woocommerce' ); ?></span>
                        </label>
                        <p class="wazap-field-hint"><?php esc_html_e( 'Show online/offline status based on hours', 'wazap-chat-share-buttons-for-woocommerce' ); ?></p>
                    </div>
                    
                    <div id="wazap-hours-settings" style="<?php echo ( get_option( 'wazap_hours_enabled', '0' ) === '1' ) ? '' : 'display:none;'; ?>">
                        <div class="wazap-field">
                            <label for="wazap_hours_timezone"><?php esc_html_e( 'Timezone', 'wazap-chat-share-buttons-for-woocommerce' ); ?></label>
                            <select id="wazap_hours_timezone" name="wazap_hours_timezone" class="wazap-select">
                                <option value="Europe/Berlin" <?php selected( get_option( 'wazap_hours_timezone', 'Europe/Berlin' ), 'Europe/Berlin' ); ?>>Europe/Berlin</option>
                                <option value="Europe/London" <?php selected( get_option( 'wazap_hours_timezone' ), 'Europe/London' ); ?>>Europe/London</option>
                                <option value="America/New_York" <?php selected( get_option( 'wazap_hours_timezone' ), 'America/New_York' ); ?>>America/New_York</option>
                                <option value="America/Los_Angeles" <?php selected( get_option( 'wazap_hours_timezone' ), 'America/Los_Angeles' ); ?>>America/Los_Angeles</option>
                                <option value="Asia/Tokyo" <?php selected( get_option( 'wazap_hours_timezone' ), 'Asia/Tokyo' ); ?>>Asia/Tokyo</option>
                                <option value="Asia/Kolkata" <?php selected( get_option( 'wazap_hours_timezone' ), 'Asia/Kolkata' ); ?>>Asia/Kolkata</option>
                                <option value="Australia/Sydney" <?php selected( get_option( 'wazap_hours_timezone' ), 'Australia/Sydney' ); ?>>Australia/Sydney</option>
                            </select>
                        </div>
                        
                        <div class="wazap-field">
                            <label><?php esc_html_e( 'Weekday Hours (Mon-Fri)', 'wazap-chat-share-buttons-for-woocommerce' ); ?></label>
                            <div class="wazap-time-range">
                                <input type="time" name="wazap_hours_weekday_start" value="<?php echo esc_attr( get_option( 'wazap_hours_weekday_start', '09:00' ) ); ?>" class="wazap-input wazap-input-sm">
                                <span><?php esc_html_e( 'to', 'wazap-chat-share-buttons-for-woocommerce' ); ?></span>
                                <input type="time" name="wazap_hours_weekday_end" value="<?php echo esc_attr( get_option( 'wazap_hours_weekday_end', '18:00' ) ); ?>" class="wazap-input wazap-input-sm">
                            </div>
                        </div>
                        
                        <div class="wazap-field">
                            <label class="wazap-toggle">
                                <input type="checkbox" name="wazap_hours_weekend_enabled" value="1" id="wazap_weekend_toggle" <?php checked( get_option( 'wazap_hours_weekend_enabled', '0' ), '1' ); ?>>
                                <span class="wazap-toggle-slider"></span>
                                <span class="wazap-toggle-label"><?php esc_html_e( 'Open on Weekends', 'wazap-chat-share-buttons-for-woocommerce' ); ?></span>
                            </label>
                        </div>
                        
                        <div id="wazap-weekend-hours" style="<?php echo ( get_option( 'wazap_hours_weekend_enabled', '0' ) === '1' ) ? '' : 'display:none;'; ?>">
                            <div class="wazap-field">
                                <label><?php esc_html_e( 'Weekend Hours (Sat-Sun)', 'wazap-chat-share-buttons-for-woocommerce' ); ?></label>
                                <div class="wazap-time-range">
                                    <input type="time" name="wazap_hours_weekend_start" value="<?php echo esc_attr( get_option( 'wazap_hours_weekend_start', '10:00' ) ); ?>" class="wazap-input wazap-input-sm">
                                    <span><?php esc_html_e( 'to', 'wazap-chat-share-buttons-for-woocommerce' ); ?></span>
                                    <input type="time" name="wazap_hours_weekend_end" value="<?php echo esc_attr( get_option( 'wazap_hours_weekend_end', '14:00' ) ); ?>" class="wazap-input wazap-input-sm">
                                </div>
                            </div>
                        </div>
                        
                        <div class="wazap-field">
                            <label for="wazap_offline_message"><?php esc_html_e( 'Offline Message', 'wazap-chat-share-buttons-for-woocommerce' ); ?></label>
                            <input type="text" id="wazap_offline_message" name="wazap_offline_message" value="<?php echo esc_attr( get_option( 'wazap_offline_message', 'We are currently offline. Leave a message!' ) ); ?>" class="wazap-input">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Cart Recovery -->
            <div class="wazap-card">
                <div class="wazap-card-header">
                    <h2><?php esc_html_e( 'Cart Recovery', 'wazap-chat-share-buttons-for-woocommerce' ); ?></h2>
                    <span class="wazap-badge wazap-badge-free"><?php esc_html_e( 'FREE', 'wazap-chat-share-buttons-for-woocommerce' ); ?></span>
                </div>
                <div class="wazap-card-body">
                    <div class="wazap-field">
                        <label class="wazap-toggle">
                            <input type="checkbox" name="wazap_cart_recovery_enabled" value="1" <?php checked( get_option( 'wazap_cart_recovery_enabled', '1' ), '1' ); ?>>
                            <span class="wazap-toggle-slider"></span>
                            <span class="wazap-toggle-label"><?php esc_html_e( 'Enable Cart Recovery', 'wazap-chat-share-buttons-for-woocommerce' ); ?></span>
                        </label>
                        <p class="wazap-field-hint"><?php esc_html_e( 'Show a popup when customers return after abandoning cart', 'wazap-chat-share-buttons-for-woocommerce' ); ?></p>
                    </div>
                    
                    <div class="wazap-field">
                        <label for="wazap_cart_recovery_delay"><?php esc_html_e( 'Show popup after (minutes)', 'wazap-chat-share-buttons-for-woocommerce' ); ?></label>
                        <select id="wazap_cart_recovery_delay" name="wazap_cart_recovery_delay" class="wazap-select">
                            <option value="30" <?php selected( get_option( 'wazap_cart_recovery_delay', '60' ), '30' ); ?>>30 <?php esc_html_e( 'minutes', 'wazap-chat-share-buttons-for-woocommerce' ); ?></option>
                            <option value="60" <?php selected( get_option( 'wazap_cart_recovery_delay', '60' ), '60' ); ?>>1 <?php esc_html_e( 'hour', 'wazap-chat-share-buttons-for-woocommerce' ); ?></option>
                            <option value="120" <?php selected( get_option( 'wazap_cart_recovery_delay', '60' ), '120' ); ?>>2 <?php esc_html_e( 'hours', 'wazap-chat-share-buttons-for-woocommerce' ); ?></option>
                            <option value="1440" <?php selected( get_option( 'wazap_cart_recovery_delay', '60' ), '1440' ); ?>>24 <?php esc_html_e( 'hours', 'wazap-chat-share-buttons-for-woocommerce' ); ?></option>
                        </select>
                    </div>
                    
                    <div class="wazap-field">
                        <label for="wazap_cart_recovery_message"><?php esc_html_e( 'Recovery Message', 'wazap-chat-share-buttons-for-woocommerce' ); ?></label>
                        <input type="text" id="wazap_cart_recovery_message" name="wazap_cart_recovery_message" value="<?php echo esc_attr( get_option( 'wazap_cart_recovery_message', 'Still thinking about it? We can help!' ) ); ?>" class="wazap-input">
                    </div>
                </div>
            </div>

            <!-- Analytics -->
            <div class="wazap-card">
                <div class="wazap-card-header">
                    <h2><?php esc_html_e( 'Analytics', 'wazap-chat-share-buttons-for-woocommerce' ); ?></h2>
                </div>
                <div class="wazap-card-body">
                    <div class="wazap-field">
                        <label class="wazap-toggle">
                            <input type="checkbox" name="wazap_ga_enabled" value="1" <?php checked( get_option( 'wazap_ga_enabled', '0' ), '1' ); ?>>
                            <span class="wazap-toggle-slider"></span>
                            <span class="wazap-toggle-label"><?php esc_html_e( 'Send events to Google Analytics', 'wazap-chat-share-buttons-for-woocommerce' ); ?></span>
                        </label>
                        <p class="wazap-field-hint"><?php esc_html_e( 'Requires GA4 to be installed on your site', 'wazap-chat-share-buttons-for-woocommerce' ); ?></p>
                    </div>
                    
                    <div class="wazap-field">
                        <label class="wazap-toggle">
                            <input type="checkbox" name="wazap_fb_pixel_enabled" value="1" <?php checked( get_option( 'wazap_fb_pixel_enabled', '0' ), '1' ); ?>>
                            <span class="wazap-toggle-slider"></span>
                            <span class="wazap-toggle-label"><?php esc_html_e( 'Send events to Facebook Pixel', 'wazap-chat-share-buttons-for-woocommerce' ); ?></span>
                        </label>
                        <p class="wazap-field-hint"><?php esc_html_e( 'Requires Facebook Pixel to be installed', 'wazap-chat-share-buttons-for-woocommerce' ); ?></p>
                    </div>
                </div>
            </div>

            <!-- Display Rules -->
            <div class="wazap-card">
                <div class="wazap-card-header">
                    <h2><?php esc_html_e( 'Display Rules', 'wazap-chat-share-buttons-for-woocommerce' ); ?></h2>
                </div>
                <div class="wazap-card-body">
                    <div class="wazap-field-row">
                        <div class="wazap-field">
                            <label class="wazap-toggle">
                                <input type="checkbox" name="wazap_show_on_mobile" value="1" <?php checked( get_option( 'wazap_show_on_mobile', '1' ), '1' ); ?>>
                                <span class="wazap-toggle-slider"></span>
                                <span class="wazap-toggle-label"><?php esc_html_e( 'Show on Mobile', 'wazap-chat-share-buttons-for-woocommerce' ); ?></span>
                            </label>
                        </div>
                        
                        <div class="wazap-field">
                            <label class="wazap-toggle">
                                <input type="checkbox" name="wazap_show_on_desktop" value="1" <?php checked( get_option( 'wazap_show_on_desktop', '1' ), '1' ); ?>>
                                <span class="wazap-toggle-slider"></span>
                                <span class="wazap-toggle-label"><?php esc_html_e( 'Show on Desktop', 'wazap-chat-share-buttons-for-woocommerce' ); ?></span>
                            </label>
                        </div>
                    </div>
                    
                    <div class="wazap-field">
                        <label for="wazap_hide_on_pages"><?php esc_html_e( 'Hide on Pages', 'wazap-chat-share-buttons-for-woocommerce' ); ?></label>
                        <input type="text" id="wazap_hide_on_pages" name="wazap_hide_on_pages" value="<?php echo esc_attr( get_option( 'wazap_hide_on_pages', '' ) ); ?>" placeholder="cart, checkout, my-account" class="wazap-input">
                        <p class="wazap-field-hint"><?php esc_html_e( 'Comma-separated page slugs where widget should be hidden', 'wazap-chat-share-buttons-for-woocommerce' ); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="wazap-submit-row">
            <?php submit_button( esc_html__( 'Save Settings', 'wazap-chat-share-buttons-for-woocommerce' ), 'primary wazap-submit-btn', 'submit', false ); ?>
        </div>
    </form>
    
    <div class="wazap-footer">
        <p><?php esc_html_e( 'Made with', 'wazap-chat-share-buttons-for-woocommerce' ); ?> ❤️ <?php esc_html_e( 'by', 'wazap-chat-share-buttons-for-woocommerce' ); ?> <a href="https://get-wazap.com" target="_blank">Wazap</a></p>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    $('#wazap_agents_toggle').on('change', function() {
        $('#wazap-agents-list').toggle(this.checked);
    });
    
    $('#wazap_hours_toggle').on('change', function() {
        $('#wazap-hours-settings').toggle(this.checked);
    });
    
    $('#wazap_weekend_toggle').on('change', function() {
        $('#wazap-weekend-hours').toggle(this.checked);
    });
});
</script>
