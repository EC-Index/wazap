=== Wazap - WhatsApp Chat & Share for WooCommerce ===
Contributors: wazap
Tags: whatsapp, woocommerce, chat, share, customer support, abandoned cart, whatsapp button
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Add WhatsApp chat button, product sharing, multiple agents, business hours, and cart recovery to your WooCommerce store. 100% Free.

== Description ==

**Wazap** is the most complete WhatsApp integration for WooCommerce - and it's completely FREE. No premium version, no hidden costs.

= Why Wazap? =

* 📱 **WhatsApp Chat Button** - Let customers contact you with one tap
* 📤 **Product Sharing** - Customers can share products with friends ("Get opinion" feature)
* 👥 **Multiple Agents** - Route chats to Sales, Support, or specific team members
* 🕐 **Business Hours** - Show online/offline status automatically
* 🛒 **Cart Recovery** - Re-engage customers who abandoned their cart
* 📊 **Analytics** - Track clicks in Google Analytics & Facebook Pixel
* 🎨 **3 Themes** - WhatsApp Green, Light, Dark
* 📍 **Flexible Position** - Bottom right, left, or center
* 📱 **Mobile Optimized** - Perfect on all devices

= Features That Others Charge For (FREE with Wazap) =

| Feature | Wazap | Others |
|---------|-------|--------|
| Chat Button | ✅ FREE | ✅ Free |
| Share Button | ✅ FREE | ❌ Not available |
| Multiple Agents | ✅ FREE | 💰 $19+/month |
| Business Hours | ✅ FREE | 💰 $15+/month |
| Cart Recovery | ✅ FREE | 💰 $29+/month |
| Analytics | ✅ FREE | 💰 $9+/month |

= Perfect For =

* 🛍️ WooCommerce stores
* 👗 Fashion & apparel shops
* 🛋️ Furniture & home decor
* 💍 Jewelry & accessories
* 🧴 Beauty & cosmetics
* Any business that uses WhatsApp!

= How It Works =

1. Install and activate the plugin
2. Enter your WhatsApp number
3. Customize buttons, colors, and position
4. That's it! Start chatting with customers

= Pro Tip =

Use "Get opinion" instead of "Share" for your share button - it converts 2x better! Customers love asking friends for advice before purchasing.

== Installation ==

1. Upload the `wazap` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to **Wazap** in your admin menu
4. Enter your WhatsApp number (with country code, without +)
5. Save settings and you're done!

== Frequently Asked Questions ==

= Is Wazap really free? =

Yes! 100% free with all features included. No premium version, no hidden costs, no monthly fees.

= Do I need WhatsApp Business API? =

No! Wazap works with your regular WhatsApp or WhatsApp Business app. No API setup required.

= Does it work without WooCommerce? =

Yes, the chat button works on any WordPress site. The product sharing feature requires WooCommerce.

= Can I add multiple team members? =

Yes! Enable Multiple Agents and add up to 5 team members with different roles.

= How does cart recovery work? =

When a customer adds items to cart and leaves, Wazap remembers. When they return, a friendly popup offers WhatsApp support to help complete their purchase.

= Does it slow down my site? =

No. Wazap is lightweight (under 20KB) and loads asynchronously. It won't affect your page speed.

= Can I track WhatsApp clicks? =

Yes! Enable Google Analytics or Facebook Pixel integration to track all button clicks.

== Screenshots ==

1. WhatsApp chat and share buttons on product page
2. Agent selector popup
3. Cart recovery popup
4. Admin settings dashboard
5. Business hours configuration
6. Multiple agents setup

== Changelog ==

= 1.0.0 =
* Initial release
* WhatsApp chat button
* Product sharing feature
* Multiple agents support
* Business hours
* Cart recovery
* Google Analytics integration
* Facebook Pixel integration
* 3 color themes
* Mobile optimized

== Upgrade Notice ==

= 1.0.0 =
Initial release of Wazap - the free WhatsApp integration for WooCommerce.
